
#include <string>
#include <vector>
#include <time.h>
#include <iostream>
#include <iostream>
#include <cstdlib>
#include <iomanip> 

using namespace std;

_Uint32t Ch(_Uint32t  x, _Uint32t y, _Uint32t z) {
	return (x & y) ^ (~x & z);
};

_Uint32t Maj(_Uint32t  x, _Uint32t  y, _Uint32t  z) {
	return (x & y) ^ (x & z) ^ (y & z);
};

_Uint32t sigma_upper_0(_Uint32t  x) {
	return ((x << (32 - 2)) | (x >> 2)) ^ ((x << (32 - 13)) | (x >> 13)) ^ ((x << (32 - 22)) | (x >> 22));
};

_Uint32t sigma_upper_1(_Uint32t  x) {
	return ((x << (32 - 6)) | (x >> 6)) ^ ((x << (32 - 11)) | (x >> 11)) ^ ((x << (32 - 25)) | (x >> 25));
};


void printresult(vector<_Uint32t> vector) {
	for (int i = 0; i < vector.size(); i++) {
		cout << "x\"" << setfill('0') << setw(8) << hex << vector[i] << "\"," << endl;
	}
}



int main() {

	vector<_Uint32t> entree(64);
	vector<_Uint32t> sortie(64);

	//valeurs � v�rifier:
	entree =
	{ 0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
		0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
		0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
		0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
		0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
		0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
		0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
		0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2 };

	_Uint32t H0 = 0x6a09e667;
	_Uint32t   H1 = 0xbb67ae85;
	_Uint32t  H2 = 0x3c6ef372;
	_Uint32t  H3 = 0xa54ff53a;
	_Uint32t  H4 = 0x510e527f;
	_Uint32t  H5 = 0x9b05688c;
	_Uint32t  H6 = 0x1f83d9ab;
	_Uint32t  H7 = 0x5be0cd19;
	_Uint32t  w = 0x00000000;
	const _Uint32t  K = 0x428a2f98;

	_Uint32t  a = 0;
	_Uint32t  b = 0;
	_Uint32t  c = 0;
	_Uint32t  d = 0;
	_Uint32t  e = 0;
	_Uint32t  f = 0;
	_Uint32t  g = 0;
	_Uint32t  h = 0;
	_Uint32t  T1 = 0;
	_Uint32t  T2 = 0;

	printresult(entree);
	for (int i = 0; i < 64; i++) {
		a = H0;
		b = H1;
		c = H2;
		d = H3;
		e = H4;
		f = H5;
		g = H6;
		h = H7;
		w = entree[i];
		T1 = h + sigma_upper_1(e) + Ch(e, f, g) + K + w;
		T2 = sigma_upper_0(a) + Maj(a, b, c);
		h = g;
		g = f;
		f = e;
		d = e + T1;
		d = c;
		c = b;
		b = a;
		a = T1 + T2;
		H0 = a + H0;
		H1 = b + H1;
		H2 = c + H2;
		H3 = d + H3;
		H4 = e + H4;
		H5 = f + H5;
		H6 = g + H6;
		H7 = h + H7;
		_Uint32t sortie0 = H0;
		_Uint32t sortie1 = H1;
		_Uint32t sortie2 = H2;
		_Uint32t sortie3 = H3;
		_Uint32t sortie4 = H4;
		_Uint32t sortie5 = H5;
		_Uint32t sortie6 = H6;
		_Uint32t sortie7 = H7;
		//uint32_t sortie = sortieI0 + sortieI1 + sortieI2 + sortieI3 + sortieI4 + sortieI5 + sortieI6 + sortieI7;

		cout << "x\"" << hex << sortie0 << sortie1 << sortie2 << sortie3 << sortie4 << sortie5 << sortie6 << sortie7 << "\", " << endl;
	};
	system("pause");
	return 0;
};

//x"a89c9e4c257194ecf7d6a1f7e1bee8aca21ca4feec13bb0bba8942377b64a6c4",
//x"4b72d05bce0e33381d4836e3d9958aa3443949fc8e306009a69cfd4235ede8fb",
//x"dd2f2a1b19810393eb566a1bf6ddc186887293f8d269aa0534cd5d4bdc8ae63d",
//x"33a59897f6b02dae4d76daee2342ba110e527f05adc3dfd737075011584388",
//x"fa6f39aa2a55c645fb879b5ce70b994f21ca4fe06bc165ed6213454d188f4ad8",
//x"76623ea424c4ffef25dd61a1e29334ab43949fc08d8bb5cdcdd4ab3a7aa29025",
//x"bdf24d29b273e934aa26190870964c87293f80d120558d5b60610748773b5f",
//x"668cca33a7066365e5c9a0235312f7dce527f005849950d2c80b694a3d79c66",
//x"b95b87a4d932d988cd0038838dc97ff1ca4fe00669c140d84ca4ba1d05852fa",
//x"de4399c6eeb53c9a633120c5ac9b873949fc008341120deb665fae55229e9b",
//x"4d1fdd5ac7ccf8d56151e65c600fcca77293f800bc8b0e0d6ea771bb4088fe49",
//x"f65da35714ecd62f291edf31c161b303e527f0002f1f060d2b327fc8af307004",
//x"e0604893b4a79863e0bb560ea809234ca4fe0001446f60d5a5185d5da62efcc",
//x"1b334e0cebaac21949562ee6288c4794949fc000de96d60d6e987be234b475a1",
//x"814c6b016de10253500f0ff71e2767a293f80007336960d4d2f51efa34cf183",
//x"3c97b02e882a7b263bdf0124a6e36779527f00009c76160dc065e7fcf07c4372",
//x"aca80a28c4c22b54c4097c4ae2c2689da4fe0000eef5160d5cdbfe09b0e22b6e",
//x"a920020f716a357c88cba79ea6cbe4e749fc000093f3160d4bd11416dbe2977",
//x"2ff17ae31a8a378bfa35dd1a2f978c8593f80000ddef160ddfc42a23598f3d8d",
//x"e02180574a7bb26e14c014a529cd699f27f0000071e7160dbdb34030395367b0",
//x"f97e91512a9d32c55f3bc7133e8d7e444fe0000099d7160d2f9a563df706a7e0",
//x"22697b6d241bc41689d8f9d89dc945579fc00000e9b7160dc9716c4a26a0fe1d",
//x"eadcaa0c46853f83adf4bdee27a23f2f3f8000008977160db3288257f0126a67",
//x"e5e24eb63161e98ff479fd71d596fd1d7f000000c8f7160d3c9f9864a33aecbe",
//x"69d089e01744384525dbe700ca10fa8efe00000047f7160d596ae71dfda8522",
//x"bd070a928114c2253d201f45efece18efc00000045f7160d4d8dc47ee5713393",
//x"838544ee3e1bccb7be34e16a2d0d00d3f800000041f7160d9384da8b32fef811",
//x"50888372c1a111a5fc50ae21eb41e23df000000039f7160dd57bf098c683d29c",
//x"d80e73a412299517bdf1bfc6e792905ee000000029f7160df7306a59bffc334",
//x"ea64864cea3808bbd01b54dda5845024c00000009f7160d396a1cb2ab72c9d9",
//x"a0cd461bd49c8f07ba535d98759fa50180000000c9f7160d436132bfe4dce68b",
//x"40a2412e7569d5228eefec9f2ff30299049f7160dd5848cc283e194a",
//x"35c3ceeab60c1650459c1c1bee2ef38049f7160d574f5ed935966216",
//x"5cb39cdcebcfe53aba65d811c33cb0f9049f7160da14674e68ce5c0ef",
//x"553bc03648838216a635bd4b7da2890a049f7160deb3d8af32e2c35d5",
//x"c497be469dbf424ceeb93f6123d84655049f7160d3534a1001969c0c8",
//x"a574d17c625700928c7881ad129185b6049f7160d7f2bb70d4e9e61c8",
//x"42a593cc7cbd20eeecf823f9f0a0763049f7160dc922cd1acdca18d5",
//x"fd3345644a7165daf69b544d8dd989a2049f7160d1319e32796ece5ef",
//x"53e85b1a47a4ab3e410cba278474ddef049f7160d5d10f934aa06c916",
//x"713bd1a69b8d065888b16565c5819816049f7160da7080f41717c24a",
//x"a1f562ebcc8d7fe243e6bbd4e32fd7b049f7160df0ff254eae1fd18b",
//x"95927261aebe3ae9310743bb72716938049f7160d3af63b5b9f1ef6d9",
//x"eed64f164450ad4adfc57ea4a378acf3049f7160d84ed5168da153234",
//x"cb0918353326fc6024162bee833e2b97049f7160dcee467755f02839c",
//x"cc263acffe301495573d284ea7545785049f7160d18db7d822de6eb11",
//x"e5521200ca564f64556d3ce3fe917fd3049f7160d62d2938f46c26893",
//x"884daa0fafa861641fc38c4753febcb6049f7160dacc9a99ca994fc22",
//x"4f6bff9137f60b73cf6bedab73c248fd049f7160df6c0bfa9565ea5be",
//x"4d67b1d187620b04761f91e432e36a8049f7160d40b7d5b64d1f6567",
//x"8f8a0f62d4c9bcd58ec404224a902fc6049f7160d8aaeebc38dd73b1d",
//x"9edea4a76453cc37638dc0f7d95433e8049f7160dd4a601d0188626e0",
//x"26aa900033270dec7e18d2e3ce1f4df049f7160d1e9d17dded2c28b0",
//x"ef64cc4b29dd00decb13fe0c4c3820d049f7160d68942deabc9408d",
//x"f7f668801941cd29f4f0feeacfd78019049f7160db28b43f7745d6e77",
//x"5fe0cd6d113835a9e32cc13c4c87f03049f7160dfc825a0426e8b26e",
//x"193dd2b0711903161f6b01bcd2fb4b16049f7160d46797011236b0c72",
//x"bc1063148a56d5c6908404d2f2664cd2049f7160d9070861e69e47c83",
//x"8bf9fded466738da1adada9882ea51a4049f7160dda679c2bfa5502a1",
//x"a5695dccd26136c7614213729dc52c3c049f7160d245eb238d4bc9ecc",
//x"b57744d477ca949333a34a39ff073fae049f7160d6e55c845f91b5104",
//x"1291678b2d41d967ab6ddecc32aa89e7049f7160db84cde5267711949",
//x"1c77f3a73fd340f2d8afb833de1868b3049f7160d243f45f1fbdf79b",
//x"ea58fc055c4b34991882f925b6c820e6049f7160d4c3b0a6c2201ebfa",